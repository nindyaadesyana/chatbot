import { ChatOllama } from "langchain/chat_models/ollama";
import { HumanMessage } from "langchain/schema";

export async function askOllamaWithLangChain(message: string) {
  const chat = new ChatOllama({
    baseUrl: "http://localhost:11434", // Ganti sesuai OLLAMA_CONFIG.URL jika perlu
    model: "llama3", // Ganti sesuai OLLAMA_CONFIG.MODEL
  });

  const response = await chat.call([new HumanMessage(message)]);
  return response.content;
}