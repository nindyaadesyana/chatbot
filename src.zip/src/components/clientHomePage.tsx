'use client';

import VoiceChatButton from "@/components/voiceChatButton";

export default function ClientHomePage() {
  return (
    <VoiceChatButton />
  );
}