import React from 'react';

const SeputarUdinusPage = () => {
    return (
        <div>
            <div className='mt-72'></div>
            <h1>3</h1>
            <p>Welcome to the Seputar Udinus page!</p>
        </div>
    );
};

export default SeputarUdinusPage;