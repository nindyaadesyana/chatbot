import React from 'react'
import NewsPage from '@/components/newsPage'

const Page = () => {
  return (
    <div>
      <NewsPage />
    </div>
  )
}

export default Page