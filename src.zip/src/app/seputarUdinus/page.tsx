import React from "react";
import SeputarUdinus from "@/components/seputarUdinus";

export default async function Seputarudinus() {
  return (
    <>
        <SeputarUdinus />
    </>
  );
}