import TVProgramPage from "@/components/TVProgramPage";

export default function ProgramPage() {
  
  return (
    <>
      <div className="bg-gray-100 min-h-screen">
        <TVProgramPage />
      </div>
    </>
  );
}
