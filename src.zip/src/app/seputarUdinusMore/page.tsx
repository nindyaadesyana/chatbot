
import React from 'react';
export default function Sales() {
  
  return (
    <>
       <div className='pt-100'>
        <h1>page testing</h1>
       </div>
    </>
  );
}