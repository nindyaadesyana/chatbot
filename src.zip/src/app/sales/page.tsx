
import SalesHome from '@/components/salesHome';
import React from 'react';
export default function Sales() {
  
  return (
    <>
       <div className='pt-100'>
        <SalesHome />
       </div>
    </>
  );
}