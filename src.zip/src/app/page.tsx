import React from 'react'
import HomePage from '@/components/homePage'

const Page = () => {
  return (
    <div>
      <HomePage />
    </div>
  )
}

export default Page